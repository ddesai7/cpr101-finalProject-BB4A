// CONVERSION MODULE SOURCE CODE 
// include the header file
#include "converting.h"

//  to define secure warnings related to some of the functions in this program
#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE 80  //  it defines a constant value for a string buffer of the maximum size

void converting(void) 
{
    // V1
    
    //it gives Demo for conversion of a string to the integer value using the atoi()
    printf("*** Start of Converting Strings to int Demo ***\n");

    char intString[BUFFER_SIZE];  // define a character array to let the user enter a input string
    int intNumber;  // it define an integer variable which is to be converted into numeric value 

    do {
        printf("Type an int numeric string (q - to quit):\n");
         // read a string from the standard input and store this int the buffer
        fgets(intString, BUFFER_SIZE, stdin); 
        intString[strlen(intString) - 1] = '\0';  // remove the newline character at the end of a string
        // using atoi() function converting the string to an integer value
        if (strcmp(intString, "q") != 0) 
        { 
            intNumber = atoi(intString);  
            printf("Converted number is %d\n", intNumber);
        }
    } while (strcmp(intString, "q") != 0); // loop will continuesly prompt to the user screen untill they quit the program by entering"q" 

    printf("*** End of Converting Strings to int Demo ***\n\n");

        // V2 
        
    //it print a message of starting the program
    printf("*** Start of Converting Strings to double Demo ***\n");

    //it defines the buffer size
    char doubleString[BUFFER_SIZE];
    double doubleNumber;//a variable

    //it will loop the program until the user enters "q" to quit
    do
    {
        // prompts the user to enter a double numeric string
        printf("Type the double numeric string (q - to quit): \n");

        //it reads a string entered by the user, stores this into the doubleString
        fgets(doubleString, BUFFER_SIZE, stdin);

        // it replaces the last character in doubleString with '\0'
        doubleString[strlen(doubleString) - 1] = '\0';

        //check if the user typed "q" 
        // If not, the string gets converted to double value using the atof function also prints it 
        if (strcmp(doubleString, "q") != 0) {
            doubleNumber = atof(doubleString);
            printf("Converted number is %f\n", doubleNumber);
        }
    } while (strcmp(doubleString, "q") != 0);
    // checks whether the user typed "q" 
    printf("*** End of Converting Strings to double Demo ***\n\n");
    // Version3 No code given 
    
}