/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#define _CRT_SECURE_NO_WARNINGS  // defines the disable warning of some functions 
// includes the structures and header to library
#include "fundamentals.h"   
#include "manipulating.h"   
#include "converting.h"   
#include "tokenizing.h"  

int main(void)      // it is a program which gives user the options to select any one of the module 
{
    char buff[10];
    do
    {   // in this program user needs to choose from 5 different options 
        printf("1 - Fundamentals\n");  
        printf("2 - Manipulating\n");  
        printf("3 - Converting\n");    
        printf("4 - Tokenizing\n");    
        printf("0 - Exit\n");          
        printf("Which module to run? \n");  // will print what module to run first to user 
        fgets(buff, 10, stdin);   
        // user needs to enter any number corresponding to the module they want to print 
        switch (buff[0])          
        // swtichs to the any of the module selected by user 
        {
        case '1': fundamentals();
            break;
        case '2': manipulating();
            break;
        case '3': converting();
            break;
        case '4': tokenizing();
            break;
        }
    } while (buff[0] != '0');  // the program will be prompted continuely to the user untill the user exits the program 
    return 0;
}