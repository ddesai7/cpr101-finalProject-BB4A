// FUNDAMENTALS MODULE SOURCE  CODE 
#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE		80
#define NUM_INPUT_SIZE  10
// include the header file
#include "fundamentals.h"

void fundamentals(void) {
	// V1 
	
	// prompt a message to the user to the start of the demo for this program 
	printf("*** Start of Indexing Strings Demo ***\n");

	// Declaring the Variables
	char buffer1[BUFFER_SIZE];
	char numInput[NUM_INPUT_SIZE];
	size_t position;

	//  in this program their is a loop which continue to prompt the string to the user untill they decide to quit by entering "q". 
	do {
		// print a non-empty string and let the user to enter a non empty string
		printf("Type not empty string (q - to quit) : \n");
		fgets(buffer1, BUFFER_SIZE, stdin);
		// the newline character will be removed at the end 
		buffer1[strlen(buffer1) - 1] = '\0';
		// Check weather the user has entered "q" to quit this program
		if (strcmp(buffer1, "q") != 0) {
			printf("Type the character position within the string:\n"); // Prompt the user to enter a input within the string
			fgets(numInput, NUM_INPUT_SIZE, stdin);
			numInput[strlen(numInput) - 1] = '\0';   // Remove the newline character at the end of the string
			position = atoi(numInput);   // Convert the position to an numInput to an integer
			// Check weather the position input is valid or not 
			if (position >= strlen(buffer1)) {
				position = strlen(buffer1) - 1;
				printf("Too big... Position reduced to max. availbale\n");
			}
			// Print the character found at a fixed position within the string itself 
			printf("The character found at %d position is \'%c\'\n",
			                (int)position, buffer1[position]) ;
		}	
	} while (strcmp(buffer1, "q") != 0);
	// prompt a message to the user to inicate the end of the demo program 
	printf("*** End of Indexing Strings Demo ***\n\n");


    //V2 

	//it Displays a message that indicates the start of the demo
	printf("*** Start of Measuring Strings Demo ***\n");

	//Variable
	char buffer2[BUFFER_SIZE];

	//Using a do-while loop to prompt the input string and position to user until they enter "q" to quit
	do{
		//it Prompts user the input string
		printf("Type a string (q - to quit):\n");
		//Reads string entered by user and store it into "buffer2" array
		fgets(buffer2, BUFFER_SIZE, stdin);	
		//Removes the newline character of the string at the end 
		buffer2[strlen(buffer2) - 1] = '\0';

		// Check if the user entered "q" to quit
		if (strcmp(buffer2, "q") != 0)
			//it Displays message that indicates the length of string
			printf("The length of \'%s\' is %d characters\n",
				buffer2, (int)strlen(buffer2));		
	} while (strcmp(buffer2, "q") != 0);

	//it Displays message to indicate the start of demo
	printf("*** End of Measuring Strings Demo ***\n\n");
    // Version3 No code given 
    
}