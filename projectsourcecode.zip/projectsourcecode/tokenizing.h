// TOKENIZING MODULE HEADER
#ifndef TOKENIZING_H
#define TOKENIZING_H
#include <stdio.h>
#include <string.h> 
// Function declaration for tokenizing.
void tokenizing(void);
#endif