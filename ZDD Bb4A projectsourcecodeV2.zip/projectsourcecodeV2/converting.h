// CONVERTING MODULE HEADER
#ifndef _CONVERTING_H_
#define _CONVERTING_H_
#include <stdio.h>
#include <string.h> 
#include <stdlib.h> 
// funcution decleration for coverting 
void converting (void);
#endif