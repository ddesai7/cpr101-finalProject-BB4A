#include <stdio.h>
#include <string.h> 
#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE 300
#include "tokenizingv2.h"

// Function to tokenize and print phrases
void tokenizing(void) {
    printf("*** start of Tokenizing phrases Demo ***\n");
    char phrases[BUFFER_SIZE];  // Buffer to store user input
    char* nextPhrase = NULL;    // Pointer to track each tokenized phrase
    int phrasesCounter;         // Counter to keep track of the number of phrases

    do {
        printf("Type a few phrases separated by a comma (q - to quit) : \n");
        fgets(phrases, BUFFER_SIZE, stdin);           // Read user input
        phrases[strlen(phrases) - 1] = '\0';         // Remove the newline character from the input

        if ((strcmp(phrases, "q") != 0)) {           // Check if the user wants to quit
            nextPhrase = strtok(phrases, ",");        // Tokenize the first phrase using ',' as the delimiter
            phrasesCounter = 1;                       // Initialize the phrase counter

            while (nextPhrase) {                      // Loop through all the tokenized phrases
                printf("Phrase #%d is \'%s\'\n", phrasesCounter++, nextPhrase); // Print the tokenized phrase
                nextPhrase = strtok(NULL, ",");        // Get the next tokenized phrase
            }
        }
    } while (strcmp(phrases, "q") != 0);              // Keep running until the user inputs 'q'

    printf("*** End of Tokenizing Phrases Demo ***\n\n");
}

// Main function where the program starts execution
int main() {
    // Call the 'tokenizing' function to start the demo.
    tokenizing();
    // Return 0 to indicate successful program execution.
    return 0;
}
