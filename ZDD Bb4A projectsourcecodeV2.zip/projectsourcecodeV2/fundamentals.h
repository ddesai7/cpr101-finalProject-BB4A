// FUNDAMENTALS MODULE HEADER
#ifndef _FUNDAMENTALS_H_
#define _FUNDAMENTALS_H_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// Function declaration for fundamentals
void fundamentals(void);
#endif