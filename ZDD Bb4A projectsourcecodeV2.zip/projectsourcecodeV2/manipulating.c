﻿#include <stdio.h>
#include <string.h>

// Define a macro to suppress warnings related to the use of "gets" function.
#define _CRT_SECURE_NO_WARNINGS

// Define a constant for the buffer size used in string manipulation.
#define BUFFER_SIZE 80

// Function to compare and manipulate strings.
void manipulating(void) {
    printf("*** start of Comparing strings Demo ***\n");

    // Declare two character arrays to store the input strings for comparison.
    char compare1[BUFFER_SIZE];
    char compare2[BUFFER_SIZE];

    // Declare a variable to store the result of string comparison.
    int result;

    // Loop to continuously compare strings until 'q' is entered.
    do {
        // Prompt the user to enter the first string to compare (or 'q' to quit).
        printf("Type the 1st string to compare (q - to quit) : \n");
        // Read the input string from the user and store it in 'compare1'.
        fgets(compare1, BUFFER_SIZE, stdin);
        // Remove the trailing newline character added by 'fgets'.
        compare1[strlen(compare1) - 1] = '\0';

        // Check if the user input is not 'q'.
        if (strcmp(compare1, "q") != 0) {
            // Prompt the user to enter the second string to compare.
            printf("Type the 2nd string to compare: \n");
            // Read the second input string from the user and store it in 'compare2'.
            fgets(compare2, BUFFER_SIZE, stdin);
            // Remove the trailing newline character added by 'fgets'.
            compare2[strlen(compare2) - 1] = '\0';

            // Compare the two strings and store the result in 'result'.
            result = strcmp(compare1, compare2);

            // Check the result of the comparison and print the appropriate message.
            if (result < 0)
                printf("'%s' string is less than '%s'\n", compare1, compare2);
            else if (result == 0)
                printf("'%s' string is equal to '%s'\n", compare1, compare2);
            else
                printf("'%s' string is greater than '%s'\n", compare1, compare2);
        }
    } while (strcmp(compare1, "q") != 0); // Continue the loop until 'q' is entered.

    printf("*** End of Comparing Strings Demo ***\n\n");
}

// Main function to start the program execution.
int main() {
    // Call the 'manipulating' function to start the demo.
    manipulating();
    // Return 0 to indicate successful program execution.
    return 0;
}
