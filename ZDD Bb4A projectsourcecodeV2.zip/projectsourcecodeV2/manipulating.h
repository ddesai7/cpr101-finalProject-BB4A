// MANIPULATING MODULE HEADER
#ifndef MANIPULATING_H 
#define MANIPULATING_H
#include <stdio.h>
#include <string.h>
// Function declaration for manipulating
void manipulating(void);
#endif
